from odoo import models,fields,api, _
import csv
import os
import logging
from odoo.exceptions import ValidationError

class SampleFather(models.Model):
    _name='muestras.father'
    _description="Modelo padre menú de muestras"
    _rec_name='lote'

    name=fields.Char(string="name")
    region=fields.Char(string="Region")
    code = fields.Char(string="Codigo del Producto")
    project = fields.Char(string=_('Proyecto'), required=True, default="",compute="_project")
    quantity_kg = fields.Float(string='Cantidad', default=0)
    price_usd = fields.Float(string='USD/kg',required=True,default="")
    pricelb=fields.Float(string="USD/lb")
    variety = fields.Text(string='Variedad',compute="_varietal")
    program = fields.Text(string='Categoria',compute="_program")
    category = fields.Text(string ='__',required=False,default="")
    location =fields.Char(string="Ubicación")
    warehouse=fields.Char(string="Bodega")
    country_origin=fields.Char(string="Origen")
    town=fields.Char(string="Region de Origen",compute="_origin_town")
    lote=fields.Char(string="Lote")
    internal_code=fields.Char(string="Código Interno")
    edition=fields.Char(string="Edicion")
    process=fields.Char(string="Proceso",compute="_process") ## Proceso de lavado
    fprocess=fields.Char(string="Proceso de Fermentación",compute="_fprocess")
    score=fields.Integer(string="SCA")
    macroprofile=fields.Char(string="Perfil Sensorial")
    mcp=fields.Char(string="Macro-Perfil",compute="_mcp")
    sca_entrega=fields.Float(string="SCA Entrega")
    sca_actual=fields.Float(string="SCA Actual")
    sku=fields.Char(string="SKU")
    condicion=fields.Char(string="Condición")
    date_create=fields.Date(string="Fecha de Creación")
    freshness=fields.Integer(string="Frescura")
    farm=fields.Char(string="Finca")
    altitude=fields.Float(string="Altitud")
    supplier=fields.Char(string="Supplier")
    
    
    # wight_uom_id=fields.Float(string="unit")
    # weight_uom_category_id = fields.Float(string="hola")
    uom=fields.Selection(
        selection=[
            ('kg','Kilogramos'),
            ('lb','Libras'),
        ],
        string="Unidad de Medida",
        default=None,
        required=True
        )
    producer=fields.Char(string="Productor")
    available=fields.Selection(
        selection=[
            ('dis','Disponible'),
            ('nodis','No Disponible'),
        ],
        string="Disponibilidad",
        default=None,
        required=True
    )

    packing_type=fields.Selection(
        selection=[
            ('bg','Bolsa'),
            ('sg','Saco'),
        ],        
        string="Tipo de Empaque",
        default=None)
    
    packing_weight=fields.Selection(
        selection=[
            ('3k','3 Kilos'),
            ('5k','5 Kilos',)
        ],
        string="Peso del empaque",
        default=None
    )


    equation_project=fields.Many2one('equation.coffee_project',string="Equation Project")
    equation_program=fields.Many2one('equation.coffee_program',string="Equation Program")
    equation_varietal=fields.Many2one('equation.coffee_varietal',string="Equation Varietal")
    equation_fermentation_process=fields.Many2one('equation.coffee_fermentation_process',string="Fermentation Process Equation")
    equation_drying_process=fields.Many2one('equation.coffee_drying_process',string="Drying Process Equation")
    equation_origin_town=fields.Many2one('equation.coffee_origin',string="Origin")
    equation_sca_score=fields.Many2one('equation.coffee_sca',string="SCA Score")
    equation_macroprofile=fields.Many2one('equation.coffee_macroprofile',string="Equation Macroprofile")
    equation_process_offering=fields.Many2one('equation.coffee_process_offering',string="Equation Offering Process")


    @api.depends('equation_project')
    def _project(self):
        for record in self:
            record.project=record.equation_project.name


    @api.depends('equation_program')
    def _program(self):
        for record in self:
            record.program=record.equation_program.name

    @api.depends('equation_varietal')
    def _varietal(self):
        for record in self:
            record.variety=record.equation_varietal.name

    @api.depends('equation_fermentation_process')
    def _fprocess(self):
        for record in self:
            record.fprocess=record.equation_fermentation_process.name


    @api.depends('equation_drying_process')
    def _process(self):
        for record in self:
            record.process=record.equation_drying_process.name

    @api.depends('equation_origin_town')
    def _origin_town(self):
        for record in self:
            record.town=record.equation_origin_town.name    
    
    @api.depends('equation_sca_score')
    def _sca(self):
        for record in self:
            record.sca_actual=record.equation_sca_score.name

    @api.depends('equation_macroprofile')
    def _mcp(self):
        for record in self:
            record.mcp=record.equation_macroprofile.name

    def mi_metodo(self):
        print('Hola')
    





