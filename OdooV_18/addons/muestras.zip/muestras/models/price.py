from odoo import models, fields, api
from datetime import date

class Price(models.Model):
    _name = "muestras.price"
    _description = "Precios Productos Disponibles"

    name = fields.Char(string="Nombre", required=True)
    value = fields.Float(string="Valor")
    date = fields.Date(string="Fecha")

    _sql_constraints = [
        ('unique_name', 'unique(name)', 'Price Type must be unique!'),
    ]

    def write(self, vals):
        res = super(Price, self).write(vals)  
        if 'value' in vals:
            for record in self:
                if record.name == "USD/COP Exchange Rate":
                    trm_value = vals.get("value", record.value) or record.value  
                    for disponible in record.env["muestras.disponible"].search([]):
                        disponible.write({"trm": trm_value})
                if record.name == "Coffee C Price":
                    price_c_value = vals.get("value", record.value) or record.value  
                    for disponible in record.env["muestras.disponible"].search([]):
                        disponible.write({"price_c": price_c_value})
                if record.name == "EUR/USD Exchange Rate":
                    eu_us_value = vals.get("value", record.value) or record.value  
                    for disponible in record.env["muestras.disponible"].search([]):
                        disponible.write({"eu_us": eu_us_value})
                if record.name == "Utilidad Microlote":
                    uml_value = vals.get("value",record.value) or record.value
                    for disponible in record.env["muestras.disponible"].search([]):
                        disponible.write({"uml":uml_value})
                if record.name == "Utilidad Regional":
                    ur_value = vals.get("value",record.value) or record.value
                    for disponible in record.env["muestras_disponible"].search([]):
                        disponible.write({"ur":ur_value})
                if record.name == "FOB Cost":
                    c_fob_value = vals.get("value",record.value) or record.value
                    for disponible in record.env["muestras.disponible"].search([]):
                        disponible.write({"c_fob":c_fob_value})
                if record.name == "Coffee Load":
                    c_fob_value = vals.get("value",record.value) or record.value
                    for disponible in record.env["muestras.disponible"].search([]):
                        disponible.write({"coffee_load":c_fob_value})
                
        return res
    
    
    @api.model
    def usd_cop(self,date=None):
        date = date or fields.Date.today()
        us_base = self.env.ref('base.USD')
        cop_base = self.env.ref('base.COP')
        company =  self.env.company

        rate = us_base._get_conversion_rate(
            us_base,
            cop_base,
            company,
            date
        )
        return rate 


# zjXLSp_3Z5pDxzFkqiYf
    